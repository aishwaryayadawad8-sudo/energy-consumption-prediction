# ✅ Objective 7: Exact Output Matching Your Screenshots

## 🎯 What You'll See

When you visit **http://127.0.0.1:8000/objective7/**, you'll see exactly these 2 charts:

---

## 📊 Chart 1: Historical Renewable Capacity

**Matches your BOTTOM screenshot**

```
╔═══════════════════════════════════════════════════════════════╗
║  📜 Historical Renewable Capacity                             ║
║  View renewable capacity trends by country                    ║
║                                                               ║
║  Renewable_Capacity                                           ║
║   10 ┤                                    ●────●              ║
║      │                                 ●──                    ║
║  9.5 ┤                              ●──        