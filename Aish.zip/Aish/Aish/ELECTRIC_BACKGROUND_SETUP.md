# Electric Lightning Background Setup Guide

## ✅ What Has Been Done

I've successfully applied the electric lightning background effect to your entire SDG 7 Dashboard project!

### Files Created/Modified:

1. **CSS File**: `sustainable_energy/static/css/electric-background.css`
   - Contains the electric blue gradient and pulsing glow effect
   - Mimics the lightning energy from your image

2. **All Templates Updated** (15 files):
   - ✅ index.html
   - ✅ objective_selector.html
   - ✅ objective1.html through objective8.html
   - ✅ send_alerts_multi.html
   - ✅ send_custom_alert.html
   - ✅ send_email_single.html
   - ✅ email_logs.html
   - ✅ admin_login.html

### What Was Added to Each Template:

```html
{% load static %}
<link rel="stylesheet" href="{% static 'css/electric-background.css' %}">
<body class="electric-bg">
```

## 🎨 Background Effect Features

The CSS creates a stunning electric lightning effect with:

- **Deep blue base**: Dark navy background (#001a33)
- **Radial gradient**: Blue tones transitioning from center to edges
- **Pulsing glow**: Animated electric blue glow at the center
- **Lightning energy**: Bright cyan/electric blue (#6dd5ed) highlights
- **Smooth animation**: 4-second pulse cycle for dynamic effect

## 🚀 How to See It in Action

### Option 1: Using the CSS Effect (Already Active!)

1. **Restart your Django server**:
   ```bash
   cd sustainable_energy
   python manage.py runserver
   ```

2. **Clear browser cache**:
   - Press `Ctrl + Shift + Delete`
   - Or `Ctrl + F5` for hard refresh

3. **Visit any page** - the background is now applied everywhere!

### Option 2: Add Your Actual Image (Optional Enhancement)

If you want to use your exact lightning image as the background:

1. **Save your image**:
   - Save the electric lightning image as: `sustainable_energy/static/images/electric-lightning.jpg`

2. **Update the CSS** (optional):
   Add this to `electric-background.css`:
   ```css
   body.electric-bg {
       background-image: url('../images/electric-lightning.jpg');
       background-size: cover;
       background-position: center;
       background-attachment: fixed;
   }
   ```

## 🎯 Current Effect

The current CSS creates an animated electric effect that:
- Pulses with energy
- Has a bright electric blue center
- Fades to dark blue at the edges
- Looks professional and modern
- Matches the energy theme of your SDG 7 project

## 🔧 Customization Options

### Adjust the Glow Intensity:
In `electric-background.css`, modify the opacity values:
```css
@keyframes electricPulse {
    0%, 100% {
        opacity: 0.7;  /* Change this (0.0 to 1.0) */
    }
    50% {
        opacity: 1;    /* Change this (0.0 to 1.0) */
    }
}
```

### Change the Animation Speed:
```css
animation: electricPulse 4s ease-in-out infinite;
                        /* ^ Change this number (seconds) */
```

### Adjust the Colors:
```css
rgba(109, 213, 237, 0.6)  /* Electric blue - change RGB values */
```

## ✨ Result

Your entire dashboard now has a stunning electric lightning background that:
- ✅ Matches the energy theme
- ✅ Looks professional and modern
- ✅ Is consistent across all pages
- ✅ Animates smoothly
- ✅ Doesn't interfere with content readability

## 📝 Notes

- The background is applied to ALL pages automatically
- Content cards remain white/visible for readability
- The effect is pure CSS - no image file needed (though you can add one)
- Works on all modern browsers
- Mobile-responsive

Enjoy your new electric lightning background! ⚡
