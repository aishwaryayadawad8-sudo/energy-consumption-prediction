html = open('test_objective5_chart_debug.html', 'w')
html.write("test")
html.close()
print("Created test file")
