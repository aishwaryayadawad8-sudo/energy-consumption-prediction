#!/usr/bin/env python3
"""
Add Country Highlighting with Pin
=================================

This script 