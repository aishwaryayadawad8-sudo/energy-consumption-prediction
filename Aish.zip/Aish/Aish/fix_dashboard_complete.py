#!/usr/bin/env python3
"""
Fix the dashboard by adding missing elements
"""

import os

def fix_dashboard_complete():
    """Add missing elements to complete the dashboard"""
    
    index_path = "sustainable_energy/dashboard/templates/dashboard/index.html"
    
    print("🔧 Fixing dashboard by adding missing elements...")
    
    try:
        with open(index_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Remove duplicate button section
        content = content.replace('''
                <div class="col-md-2">
                    <button class="btn btn-primary w-100" onclick="analyzeSelectedCountry()" 
                            style="
                                border-radius: 25px; 
                                padding: 15px 20px; 
                                font-size: 16px;
                                font-weight: 600;
                                background: #007bff;
                                border: none;
                                box-shadow: 0 2px 10px rgba(0,123,255,0.3);
                            ">
                        <i class="fas fa-search"></i> Analyze
                    </button>
                </div>
            </div>''', '')
        
        # Add missing elements at the end
        missing_elements = '''
        <!-- World Map -->
        <div id="map"></div>

        <!-- Results Section -->
        <div class="result-section" id="resultSection" style="display: none;">
            <h2 id="countryTitle">Country Analysis</h2>
            
            <!-- Metric Cards -->
            <div class="metric-cards" id="metricCards">
                <div class="metric-card">
                    <h4>Electricity Access</h4>
                    <div class="value">--</div>
                    <div class="unit">%</div>
                </div>
                <div class="metric-card">
                    <h4>CO₂ Emissions</h4>
                    <div class="value">--</div>
                    <div class="unit">Mt</div>
                </div>
                <div class="metric-card">
                    <h4>Renewable Potential</h4>
                    <div class="value">--</div>
                    <div class="unit">%</div>
                </div>
                <div class="metric-card">
                    <h4>Energy Efficiency</h4>
                    <div class="value">--</div>
                    <div class="unit">Score</div>
                </div>
            </div>
            
            <!-- Charts -->
            <div class="chart-container" id="mainChart"></div>
            <div class="chart-container" id="accessChart"></div>
            <div class="chart-container" id="renewableChart"></div>
            <div class="chart-container" id="pieChart"></div>
        </div>
    </div>

    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script>
        let map;
        let currentCountry = null;
        let currentHighlightLayer = null;
        let currentMarker = null;

        // Country coordinates with data
        const countryCoordinates = {
            'India': { lat: 20.5937, lng: 78.9629, access: 95.2, co2: 2654000 },
            'Germany': { lat: 51.1657, lng: 10.4515, access: 100.0, co2: 729000 },
            'Brazil': { lat: -14.2350, lng: -51.9253, access: 99.7, co2: 462000 },
            'China': { lat: 35.8617, lng: 104.1954, access: 100.0, co2: 10065000 },
            'United States': { lat: 39.8283, lng: -98.5795, access: 100.0, co2: 5416000 },
            'Japan': { lat: 36.2048, lng: 138.2529, access: 100.0, co2: 1162000 },
            'France': { lat: 46.6034, lng: 1.8883, access: 100.0, co2: 330000 },
            'United Kingdom': { lat: 55.3781, lng: -3.4360, access: 100.0, co2: 351000 },
            'Canada': { lat: 56.1304, lng: -106.3468, access: 100.0, co2: 672000 },
            'Australia': { lat: -25.2744, lng: 133.7751, access: 100.0, co2: 415000 }
        };

        // Available countries list
        const countries = Object.keys(countryCoordinates).sort();

        // Initialize the application
        document.addEventListener('DOMContentLoaded', function() {
            console.log('🚀 Initializing Dashboard...');
            initializeMap();
            setupSearchFunctionality();
            populateCountryDropdown();
            console.log('✅ Dashboard initialized successfully!');
        });

        function initializeMap() {
            console.log('🗺️ Initializing map...');
            
            try {
                map = L.map('map').setView([20, 0], 2);
                
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '© OpenStreetMap contributors',
                    maxZoom: 18
                }).addTo(map);
                
                console.log('✅ Map initialized successfully');
                
            } catch (error) {
                console.error('❌ Map initialization failed:', error);
            }
        }

        function setupSearchFunctionality() {
            const countryInput = document.getElementById('countryInput');
            const countrySelect = document.getElementById('countrySelect');
            const searchSuggestions = document.getElementById('searchSuggestions');
            
            if (!countryInput || !countrySelect) return;
            
            // Search input functionality
            countryInput.addEventListener('input', function() {
                const query = this.value.toLowerCase();
                if (query.length === 0) {
                    if (searchSuggestions) searchSuggestions.style.display = 'none';
                    countrySelect.value = '';
                } else {
                    filterCountries(query);
                    countrySelect.value = '';
                }
            });
            
            // Dropdown change functionality
            countrySelect.addEventListener('change', function() {
                const selectedCountry = this.value;
                if (selectedCountry) {
                    countryInput.value = selectedCountry;
                    if (searchSuggestions) searchSuggestions.style.display = 'none';
                    console.log(`🔽 Country selected from dropdown: ${selectedCountry}`);
                }
            });
        }
        
        function filterCountries(query) {
            const searchSuggestions = document.getElementById('searchSuggestions');
            if (!searchSuggestions) return;
            
            const filtered = countries.filter(country => 
                country.toLowerCase().includes(query)
            );
            
            searchSuggestions.innerHTML = '';
            searchSuggestions.style.cssText = `
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                background: white;
                border: 1px solid #e0e0e0;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                z-index: 1000;
                max-height: 300px;
                overflow-y: auto;
                display: ${filtered.length > 0 ? 'block' : 'none'};
            `;
            
            filtered.forEach(country => {
                const item = document.createElement('div');
                item.style.cssText = `
                    padding: 12px 15px;
                    cursor: pointer;
                    border-bottom: 1px solid #f0f0f0;
                    transition: background-color 0.2s;
                `;
                item.textContent = country;
                item.onmouseover = () => item.style.backgroundColor = '#f8f9fa';
                item.onmouseout = () => item.style.backgroundColor = 'white';
                item.onclick = () => selectCountryFromSearch(country);
                searchSuggestions.appendChild(item);
            });
        }

        function analyzeSelectedCountry() {
            const countryName = getSelectedCountry();
            
            if (!countryName) {
                alert('Please enter or select a country name first!');
                return;
            }

            console.log(`🔍 Analyzing: "${countryName}"`);

            // Check if country exists in our data
            let foundCountry = null;
            const countryKeys = Object.keys(countryCoordinates);
            
            if (countryCoordinates[countryName]) {
                foundCountry = countryName;
            } else {
                foundCountry = countryKeys.find(key => 
                    key.toLowerCase() === countryName.toLowerCase()
                );
            }

            if (!foundCountry) {
                alert(`Sorry, "${countryName}" is not available. Try: India, Germany, Brazil, China, etc.`);
                return;
            }

            currentCountry = foundCountry;
            console.log(`✅ Found country: ${foundCountry}`);
            
            // Highlight country on map
            highlightCountryOnMap(foundCountry);
            
            // Show results section
            showResultsSection(foundCountry);
        }

        function highlightCountryOnMap(countryName) {
            const coords = countryCoordinates[countryName];
            if (!coords || !map) return;
            
            console.log(`🎯 Highlighting ${countryName}`);
            
            // Clear existing highlights
            clearMapHighlights();
            
            // Create light green fill highlighting
            const highlightCircle = L.circle([coords.lat, coords.lng], {
                color: '#32CD32',
                fillColor: '#90EE90',
                fillOpacity: 0.6,
                radius: 500000,
                weight: 2
            }).addTo(map);
            
            // Add pin marker
            const marker = L.marker([coords.lat, coords.lng])
                .addTo(map)
                .bindPopup(`
                    <div style="text-align: center; padding: 10px;">
                        <h5>${countryName}</h5>
                        <p><strong>Electricity Access:</strong> ${coords.access}%</p>
                        <p><strong>CO₂ Emissions:</strong> ${Math.round(coords.co2 / 1000)} Mt</p>
                    </div>
                `)
                .openPopup();
            
            // Store references
            currentHighlightLayer = highlightCircle;
            currentMarker = marker;
            
            // Center map on country
            map.flyTo([coords.lat, coords.lng], 5, {
                animate: true,
                duration: 1.5
            });
        }

        function clearMapHighlights() {
            if (currentHighlightLayer) {
                map.removeLayer(currentHighlightLayer);
                currentHighlightLayer = null;
            }
            if (currentMarker) {
                map.removeLayer(currentMarker);
                currentMarker = null;
            }
        }

        function showResultsSection(countryName) {
            const coords = countryCoordinates[countryName];
            if (!coords) return;
            
            // Update title
            const titleElement = document.getElementById('countryTitle');
            if (titleElement) {
                titleElement.textContent = `${countryName} - Energy Analysis`;
            }
            
            // Update metric cards
            updateMetricCards(countryName, coords);
            
            // Show results section
            const resultSection = document.getElementById('resultSection');
            if (resultSection) {
                resultSection.style.display = 'block';
            }
            
            // Render charts
            renderCharts(countryName, coords);
        }

        function updateMetricCards(countryName, coords) {
            const metricCards = document.getElementById('metricCards');
            if (metricCards) {
                metricCards.innerHTML = `
                    <div class="metric-card">
                        <h4>Electricity Access</h4>
                        <div class="value">${coords.access}</div>
                        <div class="unit">%</div>
                    </div>
                    <div class="metric-card">
                        <h4>CO₂ Emissions</h4>
                        <div class="value">${Math.round(coords.co2 / 1000)}</div>
                        <div class="unit">Mt</div>
                    </div>
                    <div class="metric-card">
                        <h4>Renewable Potential</h4>
                        <div class="value">${Math.round(20 + coords.access * 0.3)}</div>
                        <div class="unit">%</div>
                    </div>
                    <div class="metric-card">
                        <h4>Energy Efficiency</h4>
                        <div class="value">${Math.round(60 + coords.access * 0.2)}</div>
                        <div class="unit">Score</div>
                    </div>
                `;
            }
        }

        function renderCharts(countryName, coords) {
            console.log(`📊 Rendering charts for ${countryName}`);
            
            try {
                // Simple timeline chart
                const years = [2018, 2019, 2020, 2021, 2022];
                const accessData = years.map(() => coords.access + Math.random() * 2 - 1);

                const timelineTrace = {
                    x: years,
                    y: accessData,
                    type: 'scatter',
                    mode: 'lines+markers',
                    name: `${countryName} Access`,
                    line: { color: '#3498db', width: 3 }
                };

                Plotly.newPlot('mainChart', [timelineTrace], {
                    title: `${countryName} - Electricity Access Trend`,
                    xaxis: { title: 'Year' },
                    yaxis: { title: 'Access (%)' }
                }, { responsive: true, displayModeBar: false });

                console.log(`✅ Charts rendered for ${countryName}`);
                
            } catch (error) {
                console.error(`❌ Error rendering charts:`, error);
            }
        }
        
        function populateCountryDropdown() {
            const countrySelect = document.getElementById('countrySelect');
            if (!countrySelect) return;
            
            countrySelect.innerHTML = '<option value="">-- Choose a Country --</option>';
            
            countries.forEach(country => {
                const option = document.createElement('option');
                option.value = country;
                option.textContent = country;
                countrySelect.appendChild(option);
            });
        }
        
        function selectCountryFromSearch(countryName) {
            const countryInput = document.getElementById('countryInput');
            const countrySelect = document.getElementById('countrySelect');
            const searchSuggestions = document.getElementById('searchSuggestions');
            
            if (countryInput) countryInput.value = countryName;
            if (countrySelect) countrySelect.value = countryName;
            if (searchSuggestions) searchSuggestions.style.display = 'none';
            
            highlightCountryOnMap(countryName);
            showResultsSection(countryName);
        }
        
        function getSelectedCountry() {
            const countryInput = document.getElementById('countryInput');
            const countrySelect = document.getElementById('countrySelect');
            
            if (countrySelect && countrySelect.value) {
                return countrySelect.value;
            } else if (countryInput && countryInput.value.trim()) {
                return countryInput.value.trim();
            }
            
            return '';
        }
    </script>
</body>
</html>'''
        
        # Add missing elements to the end
        content = content.rstrip() + missing_elements
        
        # Write back to file
        with open(index_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        print("✅ Successfully fixed dashboard!")
        return True
        
    except Exception as e:
        print(f"❌ Error fixing dashboard: {e}")
        return False

def main():
    """Main function"""
    print("🔧 FIXING EXPLORE DASHBOARD")
    print("=" * 40)
    
    success = fix_dashboard_complete()
    
    if success:
        print("\n✅ DASHBOARD FIXED!")
        print("=" * 40)
        print("\n🎯 Added:")
        print("   ✅ World map")
        print("   ✅ Results section")
        print("   ✅ Metric cards")
        print("   ✅ Chart containers")
        print("   ✅ Complete JavaScript")
        print("   ✅ Country data")
        print("   ✅ Search functionality")
        
        print("\n🚀 Ready to test!")
        
    else:
        print("\n❌ Fix failed.")

if __name__ == "__main__":
    main()