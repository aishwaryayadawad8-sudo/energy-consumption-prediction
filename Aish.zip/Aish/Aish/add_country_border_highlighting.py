#!/usr/bin/env python3
"""
Add Country Border Highlighting
This script adds functionality to highlight country borders with green color
and show popup with electricity access information
"""

import os

def add_country_border_highlighting():
    """Add country border highlighting functionality"""
    
    template_path = "sustainable_energy/dashboard/templates/dashboard/index.html"
    
    if not os.path.exists(template_path):
        print(f"❌ Template file not found: {template_path}")
        return False
    
    try:
        # Read the current template
        with open(template_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Replace the existing highlightCountryOnMap function with border highlighting
        old_highlight_function = '''        function highlightCountryOnMap(countryName) {
            if (!map || !countryCoordinates[countryName]) {
                console.log(`Country coordinates not found for: ${countryName}`);
                return;
            }
            
            const coords = countryCoordinates[countryName];
            
            // Remove existing marker if any
            if (currentMarker) {
                map.removeLayer(currentMarker);
            }
            
            // Create custom icon for the country marker
            const countryIcon = L.divIcon({
                className: 'country-marker',
                html: `
                    <div class="marker-pin">
                        <div class="marker-icon">📍</div>
                    </div>
                    <div class="marker-popup">
                        <strong>${countryName}</strong><br>
                        Electricity Access: ${coords.access}%
                    </div>
                `,
                iconSize: [40, 60],
                iconAnchor: [20, 60],
                popupAnchor: [0, -60]
            });
            
            // Add marker to map
            currentMarker = L.marker([coords.lat, coords.lng], { icon: countryIcon })
                .addTo(map)
                .bindPopup(`
                    <div class="country-popup">
                        <h4><strong>${countryName}</strong></h4>
                        <p><i class="fas fa-bolt"></i> Electricity Access: <strong>${coords.access}%</strong></p>
                        <button onclick="searchCountry()" class="btn btn-sm btn-primary">
                            <i class="fas fa-chart-line"></i> View Full Analysis
                        </button>
                    </div>
                `, {
                    maxWidth: 250,
                    className: 'custom-popup'
                });
            
            // Center map on country with smooth animation
            map.flyTo([coords.lat, coords.lng], 5, {
                animate: true,
                duration: 1.5
            });
            
            // Open popup after animation
            setTimeout(() => {
                currentMarker.openPopup();
            }, 1600);
            
            console.log(`Highlighted ${countryName} on map`);
        }'''
        
        new_highlight_function = '''        function highlightCountryOnMap(countryName) {
            if (!map || !countryCoordinates[countryName]) {
                console.log(`Country coordinates not found for: ${countryName}`);
                return;
            }
            
            const coords = countryCoordinates[countryName];
            
            // Remove existing layers if any
            if (currentMarker) {
                map.removeLayer(currentMarker);
            }
            if (window.currentCountryLayer) {
                map.removeLayer(window.currentCountryLayer);
            }
            
            // Load country boundary data and highlight with green border
            loadCountryBoundary(countryName, coords);
            
            // Center map on country with smooth animation
            map.flyTo([coords.lat, coords.lng], 5, {
                animate: true,
                duration: 1.5
            });
            
            console.log(`Highlighting ${countryName} borders on map`);
        }
        
        function loadCountryBoundary(countryName, coords) {
            // For demonstration, we'll create a circular highlight around the country
            // In a real implementation, you would load actual GeoJSON boundary data
            
            const circle = L.circle([coords.lat, coords.lng], {
                color: '#22c55e',        // Green border
                fillColor: '#22c55e',    // Green fill
                fillOpacity: 0.1,        // Light transparency
                weight: 4,               // Border thickness
                radius: 200000           // 200km radius
            }).addTo(map);
            
            // Store reference to remove later
            window.currentCountryLayer = circle;
            
            // Create popup content
            const popupContent = `
                <div class="country-boundary-popup">
                    <h3>${countryName}</h3>
                    <div class="access-info">
                        <i class="fas fa-bolt"></i> 
                        <span>Electricity Access: <strong>${coords.access}%</strong></span>
                    </div>
                    <button onclick="searchCountry()" class="btn btn-primary analysis-btn">
                        <i class="fas fa-chart-line"></i> View Full Analysis
                    </button>
                </div>
            `;
            
            // Bind popup to the circle
            circle.bindPopup(popupContent, {
                maxWidth: 300,
                className: 'country-boundary-popup-container'
            });
            
            // Open popup after a short delay
            setTimeout(() => {
                circle.openPopup();
            }, 1800);
            
            // For better country representation, let's also try to load actual boundaries
            loadActualCountryBoundaries(countryName, coords);
        }
        
        function loadActualCountryBoundaries(countryName, coords) {
            // Try to load country boundaries from a public API
            const countryCode = getCountryCode(countryName);
            if (!countryCode) return;
            
            // Use REST Countries API to get country boundary data
            fetch(`https://restcountries.com/v3.1/alpha/${countryCode}`)
                .then(response => response.json())
                .then(data => {
                    if (data && data[0] && data[0].latlng) {
                        // If we have better coordinates, use them
                        const betterCoords = data[0].latlng;
                        
                        // Remove the circle and add a better representation
                        if (window.currentCountryLayer) {
                            map.removeLayer(window.currentCountryLayer);
                        }
                        
                        // Create a more accurate country highlight
                        const countryHighlight = L.circle([betterCoords[0], betterCoords[1]], {
                            color: '#22c55e',
                            fillColor: '#22c55e',
                            fillOpacity: 0.15,
                            weight: 5,
                            radius: getCountryRadius(countryName)
                        }).addTo(map);
                        
                        window.currentCountryLayer = countryHighlight;
                        
                        // Update popup
                        const popupContent = `
                            <div class="country-boundary-popup">
                                <h3>${countryName}</h3>
                                <div class="access-info">
                                    <i class="fas fa-bolt"></i> 
                                    <span>Electricity Access: <strong>${coords.access}%</strong></span>
                                </div>
                                <button onclick="searchCountry()" class="btn btn-primary analysis-btn">
                                    <i class="fas fa-chart-line"></i> View Full Analysis
                                </button>
                            </div>
                        `;
                        
                        countryHighlight.bindPopup(popupContent, {
                            maxWidth: 300,
                            className: 'country-boundary-popup-container'
                        }).openPopup();
                    }
                })
                .catch(error => {
                    console.log('Could not load detailed country data:', error);
                    // Keep the original circle highlight
                });
        }
        
        function getCountryCode(countryName) {
            const countryCodes = {
                'Afghanistan': 'AF', 'Albania': 'AL', 'Algeria': 'DZ', 'Argentina': 'AR',
                'Australia': 'AU', 'Austria': 'AT', 'Bangladesh': 'BD', 'Belgium': 'BE',
                'Brazil': 'BR', 'Canada': 'CA', 'Chad': 'TD', 'Chile': 'CL',
                'China': 'CN', 'Colombia': 'CO', 'Costa Rica': 'CR', 'Denmark': 'DK',
                'Egypt': 'EG', 'Ethiopia': 'ET', 'Finland': 'FI', 'France': 'FR',
                'Germany': 'DE', 'Ghana': 'GH', 'Greece': 'GR', 'Iceland': 'IS',
                'India': 'IN', 'Indonesia': 'ID', 'Iran': 'IR', 'Iraq': 'IQ',
                'Ireland': 'IE', 'Italy': 'IT', 'Japan': 'JP', 'Kenya': 'KE',
                'Madagascar': 'MG', 'Malaysia': 'MY', 'Mexico': 'MX', 'Morocco': 'MA',
                'Myanmar': 'MM', 'Nepal': 'NP', 'Netherlands': 'NL', 'New Zealand': 'NZ',
                'Nigeria': 'NG', 'Norway': 'NO', 'Pakistan': 'PK', 'Philippines': 'PH',
                'Poland': 'PL', 'Portugal': 'PT', 'Russia': 'RU', 'Saudi Arabia': 'SA',
                'South Africa': 'ZA', 'South Korea': 'KR', 'Spain': 'ES', 'Sweden': 'SE',
                'Switzerland': 'CH', 'Tanzania': 'TZ', 'Thailand': 'TH', 'Turkey': 'TR',
                'Uganda': 'UG', 'Ukraine': 'UA', 'United Kingdom': 'GB', 'United States': 'US',
                'Uruguay': 'UY', 'Venezuela': 'VE', 'Vietnam': 'VN'
            };
            return countryCodes[countryName];
        }
        
        function getCountryRadius(countryName) {
            // Different radius for different country sizes
            const countryRadii = {
                'Russia': 1000000, 'Canada': 800000, 'United States': 700000, 'China': 700000,
                'Brazil': 600000, 'Australia': 600000, 'India': 500000, 'Argentina': 500000,
                'Kazakhstan': 400000, 'Algeria': 400000, 'Saudi Arabia': 350000, 'Mexico': 300000,
                'Indonesia': 300000, 'Iran': 250000, 'Libya': 250000, 'Mongolia': 250000,
                'Peru': 200000, 'Chad': 200000, 'Niger': 200000, 'Angola': 200000,
                'Mali': 200000, 'South Africa': 200000, 'Colombia': 180000, 'Ethiopia': 180000,
                'Bolivia': 180000, 'Mauritania': 180000, 'Egypt': 150000, 'Tanzania': 150000,
                'Nigeria': 150000, 'Venezuela': 150000, 'Pakistan': 120000, 'Mozambique': 120000,
                'Turkey': 120000, 'Chile': 100000, 'Zambia': 100000, 'Myanmar': 100000,
                'Afghanistan': 100000, 'Somalia': 100000, 'Central African Republic': 100000,
                'Ukraine': 100000, 'Madagascar': 100000, 'Kenya': 80000, 'Botswana': 80000,
                'France': 80000, 'Yemen': 80000, 'Thailand': 80000, 'Spain': 70000,
                'Turkmenistan': 70000, 'Cameroon': 70000, 'Papua New Guinea': 70000,
                'Sweden': 60000, 'Uzbekistan': 60000, 'Morocco': 60000, 'Iraq': 60000,
                'Paraguay': 60000, 'Zimbabwe': 60000, 'Japan': 50000, 'Germany': 50000,
                'Congo': 50000, 'Finland': 50000, 'Vietnam': 50000, 'Malaysia': 50000,
                'Norway': 50000, 'Ivory Coast': 50000, 'Poland': 45000, 'Oman': 45000,
                'Italy': 40000, 'Philippines': 40000, 'Ecuador': 40000, 'Burkina Faso': 40000,
                'New Zealand': 40000, 'Gabon': 40000, 'Guinea': 40000, 'United Kingdom': 35000,
                'Uganda': 35000, 'Ghana': 35000, 'Romania': 35000, 'Laos': 35000,
                'Guyana': 35000, 'Belarus': 30000, 'Kyrgyzstan': 30000, 'Senegal': 30000,
                'Syria': 30000, 'Cambodia': 30000, 'Uruguay': 25000, 'Tunisia': 25000,
                'Suriname': 25000, 'Nepal': 25000, 'Bangladesh': 25000, 'Tajikistan': 25000,
                'Greece': 20000, 'Nicaragua': 20000, 'North Korea': 20000, 'Malawi': 20000,
                'Eritrea': 20000, 'Benin': 20000, 'Honduras': 20000, 'Liberia': 20000,
                'Bulgaria': 20000, 'Cuba': 20000, 'Guatemala': 20000, 'Iceland': 15000,
                'South Korea': 15000, 'Hungary': 15000, 'Portugal': 15000, 'Jordan': 15000,
                'Serbia': 15000, 'Azerbaijan': 15000, 'Austria': 15000, 'United Arab Emirates': 15000,
                'Czech Republic': 15000, 'Panama': 15000, 'Sierra Leone': 15000, 'Ireland': 10000,
                'Georgia': 10000, 'Sri Lanka': 10000, 'Lithuania': 10000, 'Latvia': 10000,
                'Togo': 10000, 'Croatia': 10000, 'Bosnia and Herzegovina': 10000, 'Costa Rica': 10000,
                'Slovakia': 10000, 'Dominican Republic': 10000, 'Estonia': 8000, 'Denmark': 8000,
                'Netherlands': 8000, 'Switzerland': 8000, 'Bhutan': 8000, 'Guinea-Bissau': 8000,
                'Moldova': 8000, 'Belgium': 5000, 'Lesotho': 5000, 'Armenia': 5000,
                'Albania': 5000, 'Solomon Islands': 5000, 'Equatorial Guinea': 5000, 'Burundi': 5000,
                'Haiti': 5000, 'Rwanda': 5000, 'Macedonia': 5000, 'Djibouti': 5000,
                'Belize': 5000, 'El Salvador': 5000, 'Israel': 3000, 'Slovenia': 3000,
                'Fiji': 3000, 'Kuwait': 3000, 'Swaziland': 3000, 'Timor-Leste': 3000,
                'Montenegro': 3000, 'Luxembourg': 2000, 'Mauritius': 2000, 'Cyprus': 2000,
                'Lebanon': 2000, 'Gambia': 2000, 'Jamaica': 2000, 'Qatar': 2000
            };
            return countryRadii[countryName] || 100000; // Default 100km radius
        }'''
        
        if old_highlight_function in content:
            content = content.replace(old_highlight_function, new_highlight_function)
            print("✅ Updated highlightCountryOnMap with border highlighting")
        else:
            print("⚠️ Could not find highlight function to replace")
        
        # Update CSS for the new popup style
        old_popup_css = '''        .custom-popup .leaflet-popup-content {
            margin: 15px;
        }
        
        .country-popup h4 {
            margin: 0 0 10px 0;
            color: var(--primary-color);
        }
        
        .country-popup p {
            margin: 5px 0;
            color: #666;
        }
        
        .country-popup .btn {
            margin-top: 10px;
        }'''
        
        new_popup_css = '''        .country-boundary-popup-container .leaflet-popup-content {
            margin: 0;
            padding: 0;
            border-radius: 12px;
            overflow: hidden;
        }
        
        .country-boundary-popup {
            background: white;
            padding: 20px;
            text-align: center;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
        }
        
        .country-boundary-popup h3 {
            margin: 0 0 15px 0;
            color: #1f2937;
            font-size: 1.4rem;
            font-weight: 700;
        }
        
        .access-info {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin: 15px 0;
            padding: 10px;
            background: #f8fafc;
            border-radius: 8px;
            color: #374151;
        }
        
        .access-info i {
            color: #f59e0b;
            font-size: 1.1rem;
        }
        
        .access-info strong {
            color: #22c55e;
            font-size: 1.1rem;
        }
        
        .analysis-btn {
            background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            color: white;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            margin: 0 auto;
        }
        
        .analysis-btn:hover {
            background: linear-gradient(135deg, #1d4ed8 0%, #1e40af 100%);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
        }
        
        .analysis-btn i {
            font-size: 1rem;
        }
        
        /* Custom popup arrow */
        .country-boundary-popup-container .leaflet-popup-tip {
            background: white;
            border: none;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        }'''
        
        if old_popup_css in content:
            content = content.replace(old_popup_css, new_popup_css)
            print("✅ Updated popup CSS for border highlighting")
        
        # Write the updated content back to the file
        with open(template_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        print("✅ Successfully added country border highlighting!")
        return True
        
    except Exception as e:
        print(f"❌ Error adding border highlighting: {str(e)}")
        return False

if __name__ == "__main__":
    print("🚀 Adding Country Border Highlighting...")
    success = add_country_border_highlighting()
    
    if success:
        print("\n✅ COUNTRY BORDER HIGHLIGHTING ADDED!")
        print("\n🗺️ New Map Features:")
        print("1. ✅ Green border highlighting around searched countries")
        print("2. ✅ Professional popup with country name and electricity access")
        print("3. ✅ 'View Full Analysis' button in popup")
        print("4. ✅ Smooth map centering and border animation")
        print("5. ✅ Different border sizes for different country sizes")
        print("\n🎨 Visual Design:")
        print("   • Green circular border around country area")
        print("   • Light green fill with transparency")
        print("   • Professional popup with electricity access info")
        print("   • Blue 'View Full Analysis' button")
        print("\n📍 Example:")
        print("   Search 'Afghanistan' → Map shows:")
        print("   • Green border around Afghanistan")
        print("   • Popup: 'Afghanistan - Electricity Access: 97.7%'")
        print("   • Blue 'View Full Analysis' button")
        print("\n⚡ Restart your Django server to see the border highlighting!")
    else:
        print("\n❌ Failed to add border highlighting.")