()oardrgy_dashbtotal_enenced_e_enhacreat__":
    in_ma"_== __ _namee

if _return Fals        )
e}"dashboard: { Energy  Totalg enhancedcreatin"❌ Error  print(f
        as e:Exception except  
        urn True
   ret  
       ")
      soncompariformance  per 🔬 ML modelt("         prins")
 kdownrea by source🎯 Energrint("     p    
  ")ationstly visualizractive Plote   📊 Inint("       pr)
 ion charts"mix evolutEnergy  🥧 nt("         prictions")
  prediith MLimeline womplete t  📈 Crint("    p     ")
y)curacst 94.2% acXGBooshowcase (els  ML modst Beint("   🤖     pr")
   2021-2030)} TWh (0f,.re_total']:s['futu: {analysied🔮 ML Predict"        print(f0)")
   -202Wh (2000f} T,.0al']:ical_totis['historanalysical: {istor  📊 Ht(f"  prin)
       00-2030)"20,.0f} TWh (d_total']:alysis['granl: {anGrand Tota ⚡    print(f"      added:")
 Features t("📝 inpr    e")
    latempshboard trgy datal EneTod Enhanced  Create"✅   print(
            gy_html)
 _enerotalf.write(t           f:
 utf-8') as oding='nc, eth, 'w'_papen(template with o   
    y.html"total_energoard/s/dashbrd/templatedashboable_energy/tainauspath = "s template_ile
       ate f the templreate C #
          try:
   tml>'''
  ody>
</h</bript>
scs"></e.min.jp.bundlstrajs/boot0/dist/rap@5.3.t/npm/bootstdelivr.nen.js://cdrc="httpsipt s  <scrpt>

  scri  </  true});
sive: {respon mlLayout, [mlData],Chart', rformanceewPlot('mlPe.n    Plotly
        };
 }
    -serif'sans 'Inter, y:amil  font: { f         e',
 r: 'whiter_bgcolo       papafc',
     8fgcolor: '#f   plot_b       },
     
         , 100] range: [70               (%)',
 ion Accuracyredict  title: 'P             {
       yaxis:        },
  
         ngle: -45 ticka              ,
  Models''ML   title:        {
          xaxis:        
        },}
     '#1f2937' :  16, colornt: { size:fo               ions',
 dict Pree for EnergyrmancrfoPe'ML Model       text:          {
 :    title  {
        = lLayout const m  

       };    tra>'
  </exxtra>: %{y}%<e<br>Accuracy}</b>ate: '<b>%{xemplrtove    h            },

        : 0.8     opacity         
  e'],6b2c012', '#, '#7c2da3412'10c', '#9, '#c246'dc262c', '#a580316', '#e97'#for: [      col          er: {
rk    ma
        ', type: 'bar   
        .2],7, 85.4, 78, 89..3 91.5, 904.2, 92.8,      y: [9,
      ssion']egrear RLine', 'ision Tree 'Deck',woret 'Neural NtGBM',t', 'Light', 'CatBoosFores, 'Random st'XGBoo  x: ['
          {a = t mlDat       cons
 rthae Crmancel Perfo ML Mod
        // true});
responsive:yout, {a], sourceLaceDatour[srt', akdownCha'sourceBrewPlot(nelotly.     P   };

   
     or: 'white'bgcol      paper_
      if' },s-seran: 'Inter, smilyont: { fa        f,
              }  2937' }
#1fr: ': 16, colo size {       font:     030)',
    00-2 (20 Breakdownrcee Energy Soumplet: 'Co   text     
        e: {  titl
          ut = {eLayo const sourc            };

a>'
   tra></extrent}<ex<br>%{percue} TWhalb><br>%{v}</el: '<b>%{labemplatert hove      
     : 'outside',textposition     e',
       nt+valul+perce: 'labe textinfo
                   },]
    '#8b5cf6'5e',  '#22c5',4444rs: ['#ef    colo            
 {ker: mar  
         ie','p type:           uclear'],
 es', 'Nbl 'Renewassil Fuels',els: ['Fo       lab       ],
     ''
     :.0f}" + 'e_nuclear']utursis['f + analyear']ical_nuclstorysis['hi f"{anal       ''' +        ''',
   +"e']:.0f}renewabl'future_s[si'] + analyl_renewablecasis['histori+ f"{analy      '''          ''',
   +"sil']:.0f}'future_fos+ analysis[sil'] al_fos['historic"{analysis ''' + f          s: [
     value        = {
      sourceData    constn
    oweakdgy Source Br  // Ener
       true});
responsive:yout, {tributionLanData], disiobutistri, [dnChart'ibutiostr'ditly.newPlot(   Plo

          };hite'
   olor: 'waper_bgc         pf' },
    sans-seri 'Inter, { family:   font:        },
             f2937' }
 color: '#1{ size: 16,   font:     
         ibution', Distrcted Energyedivs ML-Prical : 'Histor   text   
          le: {  tit         t = {
 youbutionLaonst distri        c};

   a>'
     </extrxtra>rcent}<ebr>%{pe TWh<lue}b><br>%{vab>%{label}</ '<emplate:rthove           ',
 n: 'outsidextpositio          teue',
  ent+vall+percnfo: 'labe     texti     
  ,       }1']
     , '#10b9882f6'rs: ['#3b colo          
     rker: {     ma
       e: 'pie',yp         t,
   030)'] (2021-2-Predicted0)', 'ML(2000-202torical bels: ['His      la
       '''],0f}" +_total']:.['futuresis"{analy'' + f''', 'f}" + .0otal']:ical_t'histor{analysis[: [''' + f"     values       ta = {
onDat distributi        consbution
icted Distril vs Predtorica// His      e});

  onsive: tru {respout,MixLay], energyTrace3energyMix2, TraceenergyMixMixTrace1, ergy, [ent'har'energyMixCnewPlot(ly. Plot           };

 
   serif' }ans- 'Inter, samily: font: { f           ',
or: 'whitepaper_bgcol         c',
   afcolor: '#f8fbg plot_       
    stack',barmode: '        ' },
    nergy (%)al Ef Totage onte: 'Percetitl  yaxis: {       
    d' },Perioe: 's: { titlxaxi             },
   
        1f2937' }color: '#,  size: 16  font: {              ed',
 ML-Predictvsrical ion: Histovolut Mix Ext: 'Energy     te
           itle: {        t{
     = utrgyMixLayo   const ene
           };
5cf6' }
   '#8bor:r: { col   marke
         ype: 'bar',  t          r',
cleaame: 'Nu      n     15.0],
  + ''', f}"0:.1otal'])*10historical_t(analysis['nuclear']/l_cas['historilysinaf"{a +      y: ['''       '],
ted)icPred0 (032021-2al)', 'oric0-2020 (Hist ['200       x:{
     e3 = nergyMixTrac e     const

           }; }
 '#22c55e'r:{ colo:       marker
      pe: 'bar',   ty
         bles',: 'Renewa      name
      ,0]'', 40." + '}])*100:.1ftotal'al_s['historicnalysible']/(awarical_renehisto"{analysis['+ f    y: ['''       ed)'],
   (Predict2021-2030)', 'calistori20 (H00-20x: ['20       2 = {
     gyMixTraceonst ener      c  

   }; }
     r: '#ef4444'oloer: { c    mark
        e: 'bar', typ
           il Fuels',: 'Foss        name45.0],
    f}" + ''', )*100:.1tal']istorical_tosis['hsil']/(analystorical_fosalysis['hi' + f"{an   y: ['',
         ']edicted)0 (Pr20321-20ical)', 'toris020 (H'2000-2   x: [
         ce1 = {xTranst energyMi    coart
    olution ChEv Mix / Energy
        /: true});
 {responsivet,neLayouelice2], timTra1, timelinelineTrace', [timerteChaelinPlot('timPlotly.new

          };       }]
         12 }
   16', size:'#f973 { color:        font:     false,
    : owarrhow      s  
        tions',redicical | ML PtorHis    text: '          
   25000,          y:0.5,
           x: 202           ns: [{
io   annotat      
           }],    }
                h: 'dot'
         das      
     h: 2,widt          
          6',9731#f color: '                   ne: {
         li00,
       260     y1:           5,
   x1: 2020.               y0: 0,
           0.5,
       x0: 202   
          'line',      type:          pes: [{
        sha  
   serif' }, sans-ter,mily: 'Int: { faon        fite',
    'whcolor:  paper_bg        afc',
   '#f8f: color   plot_bg     },
          '
       '#e5e7ebr:cologrid           
     (TWh)',on tinsumpCoEnergy e: '  titl          xis: {
       ya      ,
      }
         7eb' '#e5eidcolor:       gr
         le: 'Year',         tit
       xaxis: {    },
                   }
 2937' #1fcolor: '16, : ont: { size   f         s',
    redictionne with ML Peliy Timete Energext: 'Compl  t          
    itle: {  t         
 ut = {melineLayoticonst       };

         
     }    ize: 8
           s        #10b981',
 lor: '          co     rker: {
 ma          
   },
            'dash'    dash:            : 3,
th      wid
          981',: '#10blor          co
       line: {
           s',redictionL P: 'Mname    ',
        ersarknes+me: 'li       moder',
     ype: 'scatt t          ,
 tafutureDa y:            Years,
 future       x:     ce2 = {
melineTraonst ti   c
          };
     }
      8
    e:    siz        ,
     #3b82f6'   color: '      : {
          marker    },
            : 3
          width           '#3b82f6',
 color:            {
        line:         y',
ergcal En'Historiame:       n   
   ',markers'lines+   mode:       er',
   ttca    type: 's       calData,
  histori   y:     ears,
     historicalY  x:     1 = {
     eTrace timelin  const];

      00, 252800300, 24, 23900, 243000, 2340000, 22500, 2, 22100, 21600eData = [212urt futcons
        0];8, 2029, 20327, 202, 20 20264, 2025,, 2022022, 2023s = [2021, earnst futureY      co
  
        00, 20800];900, 204 1900,900, 19418400, 18300, 17900, 0, 1716200, 1680900, 15600, 5100, 140, 100, 14800, 142, 136000, 131000, 1240, 118010500, 1120Data = [torical const his0];
       028, 2019, 217, 2015, 2016, 202012014, 13, 2012, 2011, 010, 208, 2009, 22007, 200 2006,  2004, 2005,2003,, 2002,  2001 [2000,icalYears =onst histor  c030)
      hart (2000-2ne Cte Timelile   // Comp>
     ript
    <sc>
>
    </div"></divrt-containerss="cha" claanceChartrform="mlPeiv id <d      
 </h2>mparisonance Coel Perform">🤖 ML Modction-titleass="se      <h2 clon">
  ectis="chart-slasiv c
    <d-->art nce ChrmaPerfo ML Model 
    <!--</div>
  /div>
  ner"><-contaiass="chartrt" clChaowneBreakdurcsod="iv i<d       
 0)</h2>2000-203reakdown (ource B Snergye E">🌍 Complettleion-ticlass="sect  <h2 >
      ion"rt-sect"chalass= <div c-->
   kdown Chart eaurce Br- Energy So
    <!->

    </div/div>ner"><-contais="chartt" clasarnChtributio="dis    <div id</h2>
    ionut DistribPredictedal vs ML-ic">📊 Historion-title"secth2 class=        <ion">
cts="chart-seiv clas    <d-->
ie Chart d Pvs Predicte Historical 

    <!--</div>>
    "></divt-containerass="charcl" artrgyMixChid="ene       <div >
 /h2 Evolution< MixEnergyn-title">⚡ s="sectioas     <h2 cl
   section">"chart-ss=    <div claChart -->
 Evolution  MixEnergy- 
    <!-v>
>
    </dir"></divainehart-cont" class="cart"timelineCh   <div id=2>
     /h)<2030000-ne (2ergy Timeliwered Ene">🔮 ML-Potltin-="sectio <h2 class    on">
   "chart-sectidiv class=->
    <e Chart -te Timelinmple!-- Co    <v>

  </di
     </div>div>
             </   >
  </ul               </li>
ng> total</strotrong>15% ofan> <s/spet:<0 Targ203><span> <li               >
    ong></liibution</strble contr>Staan> <strong>Trend:</sp   <li><span        
         g></li> TWh</stron.0f}" + '''lear']:,future_nucysis['al'' + f"{an> <strong>'cted:</span>Predispan      <li><     
         rong></li> TWh</st}" + '''lear']:,.0forical_nucist'h{analysis['' + f"g>'pan> <stronal:</san>Historic><sp   <li           ul>
        <             s">
 at-detail"stdiv class=  <       </div>
   nergyar eleotal nuc>TWh tscription"stat-declass="v        <di/div>
      '''<" +f}clear']):,.0uture_nusis['f+ analy] lear'torical_nuc['hisanalysis + f"{(lue">'''-vas="stat  <div clas     
     </div>           
 Energy</div>clear >Nutitle"="stat- class   <div         
    </div>              /i>
  fa-atom"><fas class="        <i            ">
 nuclear"stat-icon <div class=                er">
"stat-headss=  <div cla
          -card">="statdiv class <       y Card -->
nerg Nuclear E--  <!    >

         </div
 </div>         >
   /ul         <      li>
 /strong></otal<ong>40% of t<str/span> et:<Targan>2030      <li><sp            >
   ng></liing</stroly increasng>Rapid<stron> d:</spaan>Tren <li><sp               ></li>
    Wh</strong''' T+ ']:,.0f}" wable'future_renelysis["{ana + frong>''':</span> <stictedpan>Predi><s <l              /li>
     >< TWh</strong" + '''']:,.0f}newablel_reica['historlysis{ana f"trong>''' +:</span> <sHistoricalan><li><sp                        <ul>
    
        s">etail"stat-d class=iv<d       v>
     /dible energy<newaTWh total reiption">stat-descr="lass    <div c>
        '''</div" + .0f}wable']):,ture_rene['fulysis'] + anaablerenewal_is['historicf"{(analyslue">''' + -vas="stat<div clas     
       v>di   </   >
      ivrgy</de Ene">Renewabl-title"statlass=      <div c  v>
        /di          <>
      af"></ifas fa-les="  <i clas            ">
      renewable-icon ="statclass      <div     r">
      tat-headev class="s     <di
       ">"stat-cards=  <div clas     d -->
 y Care Energewabl!-- Ren

        <  </div>
      v>     </di   
    ul>    </            ong></li>
tal</strg>45% of to <stronget:</span>2030 Tarli><span>       <         /li>
    g><stronhare</ing srong>Decreasstspan> <end:</span>Tr   <li><            li>
     </ong>h</str'' TW,.0f}" + 'ossil']:ure_ffut{analysis[' + f"<strong>'''n> spaed:</ictn>Pred  <li><spa              /li>
    trong><'' TWh</s" + '}sil']:,.0ffosical_['historsisnaly{ag>''' + f"an> <stron/spHistorical:<n>spa<li><              
            <ul>    >
      ils""stat-deta<div class=     >
       iv</drgy fuel ene fossiltalh toion">TWt-descript"sta class=       <diviv>
     " + '''</d:,.0f}'])ilre_fosslysis['futussil'] + anafoorical_'histanalysis[' + f"{(alue">''ass="stat-viv cl         <d </div>
              iv>
/dels<l Fuossi-title">Fs="stat clas       <div        div>
           </  "></i>
    firefas fa-lass="  <i c          >
        sil" fos="stat-iconclassiv     <d           er">
 tat-headclass="s <div 
           ">"stat-card<div class=
        d -->els CarFuossil     <!-- F

    </div>v>
         </di          
    </ul>           
  li>rong></</stle models>Ensemb> <stronge:</spanyption Tpan>Predic   <li><s             
    i>/strong></lost)< (XGBo>94.2% <strong:</span>>ML Accuracyli><span         <      
     </li>/strong>ar<' TWh/ye + ''10:,.0f}"al']/['future_totis{analysg>''' + f"ronan> <st</spal Average:nnui><span>A      <l          i>
    /strong></l10 years< <strong>riod:</span> Pe><span>Time   <li                ul>
      <           ">
etailss="stat-d  <div clas  
        )</div>20302021-energy (dicted ">TWh preiptiondescr"stat-v class=di          <  '</div>
,.0f}" + ''']:uture_totallysis['fana f"{' +e">''tat-valu class="s      <divv>
             </di  /div>
   dictions<">ML Pre"stat-title<div class=       
         div>        </        "></i>
stal-ball fa-cryclass="fas   <i                 
 ">eicon futur"stat-ass=  <div cl          der">
    "stat-hea<div class=      >
      d"t-cars="sta <div clas-->
       ions Card ure Predictut- F       <!-v>

      </di </div>
   
           >       </ul    >
     </listrong>ntries</8 couong>12<strpan> rage:</slobal Cove><span>G    <li           li>
     /strong></mption<al consuActu> <strong>ity:</spanual Qpan>Data><s         <li          </li>
 strong></ TWh/year'' + 'f}",.0total']/21:'historical_"{analysis[g>''' + fn> <strone:</spaeragl Av<span>Annua       <li>         
    g></li>stronars</1 yerong>2pan> <stod:</sn>Time Peri <li><spa               <ul>
                   ">
 setailss="stat-dcla  <div     >
      020)</div0-2gy (200tal enerion">TWh toriptesc"stat-dclass= <div   >
         + '''</div}" :,.0fal']storical_tots['hiysialf"{an+ alue">''' ss="stat-v   <div cla    >
      </div           d</div>
erioal P">Historict-titleta"sdiv class=          <   
   iv>       </d>
         istory"></is="fas fa-h<i clas                   cal">
 ri-icon histostatlass="  <div c              ">
tat-headerclass="s      <div    rd">
   "stat-caass=cl  <div ->
      y Card -rgical EneHistor    <!--     grid">
"stats-v class=  <di->
   -ridstics G- Main Stati!-

    <iv></d>
    div     </
      </div>
         s</p>ele modensembl030 using -2ons for 2021edicticed ML prp>Advan    <           
 h)</div>nergy (TWdicted EL-Pre>M"elmparison-lab class="co  <div              '</div>
}" + ''total']:,.0fs['future_"{analysi'' + f">' futurevalueomparison-iv class="c       <d        >
 "ureon-card futcomparisclass="     <div           </div>
       set</p>
  l datalobass gacro2000-2020 m ion froconsumptual energy   <p>Act            v>
  gy (TWh)</diercal Enoribel">Histmparison-las="codiv clas     <         iv>
  '''</d]:,.0f}" + total'rical_s['histolysi'' + f"{anacal">'torion-value hisrismpalass="co<div c                ical">
 historrison-cardpaomclass="c     <div >
       "ison-grid"comparss=iv cla      <d</h2>
  ed EnergyctML-Prediorical vs ">Histtitleection-lass="s <h2 c">
       son-sections="comparidiv clas -->
    <omparison C vs Futurericalto  <!-- His/div>

  p>
    <    </  ccuracy
  r maximum als fo modee of top 3ng ensembl> Usi</iircle">a-info-cass="fas f cl          <i">
  : 15px;-topgin0; mar728lor: #6b; co centeralign:t-e="tex  <p styl
           </div>
   iv>   </d
         7%</div>uracy">89.el-accmodlass="ml-div c  <           div>
   Network</ral >Neu-name""ml-models= clasdiv       <      rd">
   ca"ml-model-<div class=          </div>
          </div>
    0.3%>9cy"odel-accura="ml-mass  <div cl            BM</div>
  me">LightG-na-modelass="ml     <div cl    >
       el-card"="ml-mod  <div class    iv>
             </dv>
     91.5%</diacy">urcc-aell-modlass="m     <div c           ost</div>
Bo">Catme"ml-model-nav class=       <di        ">
 l-cardss="ml-mode   <div cla
             </div>
        v>>92.8%</dicuracy"l-model-ac class="m        <div    iv>
    est</ddom Forl-name">Randelass="ml-moiv c         <d">
       -model-cardclass="mldiv     <   
     v>   </di       
  94.2%</div>">-accuracyml-modelass="div cl        <    v>
    </di">XGBoostodel-namel-m="miv class      <d          l-card">
s="ml-mode   <div clas       d">
  models-griclass="ml-iv        <d2>
 ons</hredictior Energy PL Models f">🤖 Best Mitletion-tsec<h2 class=">
        ls-section""ml-modeiv class=
    <d-->ection els S- ML Mod

    <!-
    </div>2030)</p>2000-ictions (al + ML Predstoric;">Hity: 0.95px; opacitop: 1"margin- style=  <piv>
      /dlyzed<l Energy Ana">TWh Totaelabtal-l-toss="grand   <div cla
     '</div> + ''.0f}"d_total']:,lysis['gran"{anaue">''' + f-valtalgrand-to class="iv<d    
    ">ctiontal-seand-toass="grdiv cl  <
  ection --> Total S-- Grand<!div>

    
    </       </a> Back
 -left"></i>fa-arrows "faclass=<i       
      ">ns="back-bt/" clascastsry-fore="/counthref<a      ect</p>
   Proj-7 -2030) - SDGns (2000ioedictysis & Pr Energy Analwered-Pobtitle">MLss="su <p cla       RGY</h1>
>TOTAL ENEe"tls="main-ti  <h1 clas     /div>
       <i>
  lt"></bo fa-lass="fas      <i c">
      nergy-icon"eclass= <div ">
       ader-sectionhediv class="n -->
    <Sectioeader  H-->
    <!<body</head>
/style>
   }
    <  }
     
          m;re: 3font-size             
   e {al-valuand-tot         .gr    
       }
                ize: 2rem;
ont-s       f         e {
.main-titl           
              }
           : 20px;
   padding    
         : 10px;rginma          n {
      ioels-sectmodl-     .mn,
       sectioson-ari.comp       n,
     iohart-sect       .c   
              }
   ;
          20px gap:        r;
       : 1fumnsmplate-col  grid-te              {
d els-griod       .ml-m  rid,
   on-gis  .compar
                  }
                10px;
      margin:          s: 1fr;
 lumn-template-co  grid             rid {
 ts-gsta   .    
     {h: 768px)  (max-widtdia@me  
      
          }      m: 15px;
botto margin-         74151;
   color: #3       : 600;
    ghtt-wei    fon
        -label {son .compari         
      }
       #10b981;
 lor:   co      ture {
    son-value.fucompari    .      
    
    }f6;
      r: #3b82colo     {
        calalue.historiparison-vom
        .c       }
  
       0px;ttom: 1   margin-bo       ht: 700;
  nt-weig fo           ze: 2rem;
ont-si   f       value {
  omparison-        .c
       }
   981;
       #10b 5px solidr-left:de    bor       ture {
 son-card.fu   .compari
     }
        
        b82f6;5px solid #3-left:  border           orical {
stn-card.hiompariso  .c       
     }
        
  : center;text-align          5px;
   padding: 2        10px;
    ius: border-rad         fc;
  nd: #f8fa  backgrou      
    ard {arison-c    .comp          
        }
20px;
  n-top:   margi          ap: 30px;
  g           1fr;
lumns: 1frplate-cod-temri  g         grid;
   display:
           n-grid {.compariso        
             }
);
   a(0,0,0,0.1x 30px rgb 10p: 0-shadow box   
         20px;   margin:     x;
    padding: 30p            5px;
adius: 1-rer   bord   ;
      ound: white backgr          tion {
 arison-sec .comp
                    }
   one;
-bottom: norder     b       {
t-child ls li:lasdetai    .stat-    
        
 }   5e7eb;
    d #e1px soliottom: -ber    bord       
 n;tweet: space-befy-contensti         ju: flex;
    display          
 ;ding: 5px 0ad          pli {
  tails    .stat-de      
  
       }  n: 0;
       margi     ;
     padding: 0          none;
  e:list-styl     
       l {ils uat-deta       .st        
 
        }
15px;adding:    p  
       : 8px;iusrad     border-     #f8fafc;
  kground: bac         {
    ilstadetat-  .s 
       }
              ;
bottom: 15px   margin-
         ight: 1.6;ine-he      l280;
       color: #6b7     
      tion {t-descrip     .sta 
       
       }0px;
    -bottom: 1   margin         : #f97316;
color           t: 700;
 t-weigh  fon       m;
   ize: 2.5re    font-s  e {
      tat-valu   .s   
  
        
        }937;#1f2 color:          
  ht: 600;-weig        fontm;
    : 1.3re font-size           le {
tit     .stat-      
     
        }
d 100%);c3ae 0%, #78b5cf635deg, #r-gradient(1 linead: backgroun        {
   n.nuclear -ico     .stat      
          }
  a 100%);
 a341655e 0%, #35deg, #22cent(1inear-gradiackground: l     b     e {
  n.renewablat-ico .st       
    }
     ;
       0%)106 %, #dc262 #ef4444 05deg,(13gradientund: linear- backgro   {
        on.fossil     .stat-ic     
    }
     );
       100%059669981 0%, #deg, #10b35radient(1inear-g: lackground         b {
   tureon.fut-icta   .s             
 }

       );100%ed8 , #1d46 0%, #3b82fdegadient(135linear-ground:     backgr{
        cal istoriicon.hstat-    .    
         }
    hite;
   lor: w      com;
      size: 1.5re     font-   ;
    nt: centertefy-con     justi    center;
   ems: ign-it   al         ay: flex;
  displ       10px;
    ius:rder-rad     bo    x;
   : 50p    height       
 dth: 50px;        wi
    -icon {stat
        .          }
      : 20px;
ttombo  margin-        ;
  : 15px     gap   r;
    ntegn-items: ceali         ex;
    display: fl          
 eader {at-h      .st        
       }
-5px);
   lateY(ransrm: tnsfora      t{
      er card:hov  .stat-  
       }
      ;
       easem 0.3s on: transfortisi  tran    ;
      a(0,0,0,0.1) 30px rgbadow: 0 10pxbox-sh            30px;
ng:      paddi;
       adius: 15px  border-r   e;
       hitround: w      backg      ard {
     .stat-c    
        }
    0px;
   margin: 2       0px;
     : 2ap g      r));
     (300px, 1ft, minmaxat(auto-fiepee-columns: ratempl-t    gridd;
         griay:pldis            s-grid {
 .stat  
                  }

   m: 20px;n-botto    margix;
         400pht:eig      h    iner {
  t-contahar .c
       
        
        }0,0.1);(0,0,x rgba: 0 10px 30pbox-shadow           x;
  margin: 20p         30px;
    padding: 
          px;-radius: 15    border       hite;
 ackground: w   b
         section {rt-      .cha     
      }
   rem;
    nt-size: 1.2         fo
   ight: 700;     font-we16;
       #f973r: lo     coy {
       curacodel-ac     .ml-m
                 }
 x;
 -bottom: 5p  margin         f2937;
 color: #1            600;
-weight:   font          name {
 .ml-model-    
     }
           
   6;olid #f9731t: 4px sder-lef       borer;
      centt-align:     tex    0px;
   padding: 2           
 : 10px;diusrder-ra  bo   fc;
       und: #f8fabackgro     
       card {el-od    .ml-m
    
        
        }px;bottom: 30     margin-      15px;
 :          gap    1fr));
max(200px,-fit, minat(autorepemns: plate-colud-tem        griid;
    lay: gr   disp         id {
-grl-models  .m  
      
          }  nter;
  : ce text-align        0px;
    2m:bottorgin-   ma
         937;lor: #1f2        co0;
    -weight: 60    font
        rem;ize: 1.8nt-s     foe {
       ection-titl        .s  
  }
      ;
      0,0.1)px rgba(0,0,30: 0 10px  box-shadow          
  20px;   margin:
         30px;: dding         papx;
   dius: 15border-ra            d: white;
roun       backg
     section {ls-.ml-mode    
        
       } 0.9;
     opacity:      00;
      eight: 6      font-w
       1.5rem;ize:    font-s        -label {
otald-t.gran   
                  }
  .3);
 rgba(0,0,0,0x 2px 4px ow: 2p   text-shad  
       ttom: 10px;in-borg        ma00;
    -weight: 7     fontem;
       e: 4r font-siz           {
alue rand-total-v
        .g}
        ;
        .3), 22, 0gba(249, 115px rx 40dow: 0 15pox-sha           benter;
 gn: c    text-ali  
      0px;   margin: 2      
   ing: 40px;        padd    15px;
s: adiu  border-r
          te;r: whi colo      0%);
     , #ea580c 10f97316 0%135deg, #ent(ar-gradi lineckground: ba         ion {
  d-total-sect   .gran
                  }
none;
   decoration: ext-          t;
  color: white     
       0.2);gba(0,0,0,5px rpx 1-shadow: 0 5ox       b     teY(-2px);
ranslaansform: t    tr        tn:hover {
-b    .back   
  }
       
        0.3s ease; all ion:sit        tran8px;
    p:     ga  r;
       centeems: align-it        ;
   inline-flexlay:        disp      500;
ght:wei font-           n: none;
t-decoratio tex      
     dius: 25px;ra   border-      24px;
   : 12px ding      pad
      hite; color: w   );
        3 100%0%, #4b5566b7280 5deg, #radient(13inear-gckground: lba           ck-btn {
 
        .ba           }

     0px; 2n-bottom:gi     mar
       6b7280;  color: #     2rem;
     -size: 1.      font {
      itle    .subt      
          }
  ;
  m: 10pxbotto    margin-
        f2937;color: #1          700;
  ight: nt-we       fo5rem;
      2. font-size:        
   e {n-titl    .mai
              }
      white;
 color:           em;
 -size: 2.5r font
           uto 20px;: 0 a    margin     center;
   : fy-contentsti  ju         r;
 items: centen-    alig     ;
   flex   display:       50%;
   er-radius: ord          b00%);
  %, #ea580c 1g, #f97316 05deadient(13near-grund: ligro       back
     ;t: 80px    heigh        dth: 80px;
      win {
      y-ico   .energ   
          }

        ter;cen-align:      text
       (0,0,0,0.2);x rgba0p10px 3adow: 0    box-sh         15px;
 dius:border-ra       
     rgin: 20px;     ma     px;
  ing: 30  padd          te;
: whigroundack    b       {
  ction-seeader .h
       }
                 #333;
or:        col    
ight: 100vh;   min-he      );
   0%64ba2 1067eea 0%, #7135deg, #6r-gradient(ineackground: l         ba   ;
-serifter', sans'Inmily:   font-fa       
   ody {     b
       }
            ox;
der-bg: borsizin box-       g: 0;
      paddin         in: 0;
         marg {
    >
        *
    <style   
 ipt>cr/sin.js"><est.my-laty/plotlcdn.plot.lttps://t src="h<scrip   heet">
 "styles=wap" relsplay=s&di00;500;600;7ght@300;400:wInter2?family=apis.com/cssgle//fonts.gooef="https:  <link hrn.css">
  s/all.mi.0/cs6.4-awesome/ntx/libs/foare.com/ajadfllou.cnjscdttps://="ht" hrefylesheel="st  <link reeet">
  shrel="stylein.css" ap.mbootstrdist/css/rap@5.3.0//npm/bootstdelivr.netcdn.jsps://tthref="h
    <link /title>ject<Pro) - SDG-7 s (2000-2030gy Analysial Enerot  <title>T=1.0">
  -scaletialnice-width, ievi"width=dcontent=ewport" a name="vi <met
   ">"UTF-8t= charse
    <meta<head>"en">
 lang=
<htmltml>E h!DOCTYP
<static %}{% load '' 'html =_energy_al   totmplate
 teard HTML  dashbo Energytal enhanced Toeate the 
    # Cr         }
  32987.47
l': 4and_tota   'gr    00,
     27000.clear': _nu 'future          00,
 0.200ewable': 7'future_ren            0.00,
ssil': 8100future_fo      '   000.00,
   tal': 180e_totur  'fu  
        23482.86,': l_nuclearstorica      'hi,
      61.93: 669l_renewable'torica    'his       42.68,
 ossil': 1625ical_f 'histor          987.47,
 ': 252cal_total    'histori
        sis = { analy   )
     values"g fallbacke data, usind not analyz"❌ Coul   print(   s:
   analysi    if not_ml()
_energy_withale_tot = analyz  analysist
  firs data yzeAnal  #  
  
   ")s...isualizationrd with ML Vshboa Dal Energy Totahanced Creating Ennt("🔧pri:
    _dashboard()energytal_enhanced_toate_e

def cre  return Non     
  {e}")f"❌ Error:t(      prine:
  xception as xcept E e   
   e
         return Non           s")
 ictionate predgenerCould not print("❌           e:
        els     }
         _total
 grandal':  'grand_tot       
       ure_nuclear,ar': futnucle'future_            
    e,ewabl: future_renewable'ren  'future_     ,
         uture_fossilil': fe_fossur       'fut       
  icity,ctrtal_eletouture_e_total': f      'futur         nuclear,
 ical_r': histor_nuclea 'historical              wable,
 cal_rene historible':ewal_ren 'historica            il,
   orical_fossil': histssical_foorst  'hi             
 rical_total,tal': histotorical_to    'his          urn {
        ret    
              f} TWh")
.2nd_total:,Total: {graProject omplete nt(f"   • C pri      
     ")-2030): (2000RAND TOTALf"\n🌍 Gnt(  pri        ity
  _electrice_total + futurl_totalstoricatal = hi grand_to      
     totalrand  G    #          
         
 (15.0%)") TWh 2f}:,.ure_nuclearlear: {fut"   • Nucint(f      pr)")
      .0%TWh (40:,.2f} e_renewable {futurewables:"   • Ren    print(f
        .0%)")2f} TWh (45e_fossil:,.{futurssil Fuels:    • Fo  print(f"          h")
:,.2f} TWectricitye_total_elcity: {futurtal Electri To   •t(f"       prin)
     021-2030):"edictions (2Future Prf"🔮      print(       
            
nd 15%rou Stable a* 0.15  #electricity re_total_clear = futufuture_nu          o 40%
  m ~27% teasing frocrIn#   icity * 0.40ctrtal_elee_to= futurle wab future_rene   
         45% ~65% tofromg creasin45  # Deity * 0._electricotalfuture_te_fossil =      futur      fossil)
  es, lesse renewabl (morix evolutionenergy m # Project                  
  ricity
     is electal energyof tot0% # Assume 40.4  m() * ].suonsumption'dicted_cture_df['prericity = fuotal_electfuture_t        ends
    d on trrgy mix basee enefuturstimate     # E           
       ions)
  ture_predictaFrame(fu = pd.Datuture_df    f:
        onsctiure_predi   if fut    
     
    adhe# 10 years amption(10)  future_consuor.predict_ predictedictions =ture_pr
        fu...")or 2021-2030ictions fML prednerating 🔮 Gerint("        p
30)(2021-20predictions rate future  Gene     #       
 
   ")00:.1f}%)al_total*1ear/historiccltorical_nu({hisWh :,.2f} Tearuclorical_nclear: {hist • Nu(f"      print")
    %)tal*100:.1f}ical_toable/historl_renewhistorica} TWh ({e:,.2fablnewcal_re: {historiRenewablest(f"   •        prin)")
 al*100:.1f}%ical_tothistoral_fossil/ictor} TWh ({his.2fcal_fossil:,historils: { Fossil Fue  •int(f"   pr")
      ,.2f} TWhcal_total:ty: {historictrici Total Ele"   •t(f       prin
 -2020):")(2000ysis rical Anal(f"📊 Histo  print      
        enewable
torical_rear + hisal_nuclistoricfossil + htorical_otal = historical_t     his
   Wh)'].sum()enewables (Tom ricity fr= df['Electrenewable l_rcahistori()
        .sumTWh)']ar (y from nucle['Electricit df =nuclearl_rica  histo()
      sum'].h)ls (TWl fuerom fossilectricity f'Eil = df[al_fossstoric his
       ricity totalcal electhistoriculate        # Cal     
 ce')
   coer errors='l],umeric(df[co.to_nol] = pd        df[cs:
        columncol in df.      if      ty_cols:
 electricifor col in        totals
 alculate  Clean and c    #           
h)
 (csv_patcsv = pd.read_
        dfissive analysrehena for compatLoad raw d
        #      Wh)']
   bles (Trom renewatricity fTWh)', 'Elecom nuclear (ctricity fr, 'Eleuels (TWh)'fossil fricity from lect = ['Ety_colsrici  elect      lectricity
als for estorical totCalculate hi        #   
    al_data)
  istoricame(htaFr pd.Datorical_df =      hisata()
  storical_dictor.get_hi preddata =cal_ri  histodata
      cal Get histori      #        
  a()
 atean_dd_and_cledictor.loa       prath)
 r(csv_ptionPredictoergyConsumptor = En    predic
    .csv'ble-energyn-sustainata-ol-daglobaath = 'v_p    csictor
    lize predInitia
        #        edictor
 sumptionPryConnergport Eor imon_predictsumptiy_condels.energ from ml_mo       
 try:    
   .")
l 2030..ntidictions uL preata with M Energy dng Totalzily🔍 Anaint("   prml():
 gy_with__eneryze_total

def analgy')le_enertainab('sus.path.appendn path
syso Pythory trgy directo_ene sustainablehe
# Add tt os
 sys
impor pd
importast pandas por""

im charts
"ivectterad in anedictionsnergy prodels for e ML msts the be2030
Useup to tions ed visualizah ML-powerard witDashbotal Energy  Tohancedreate En
C"""thon3
v pyin/en/usr/b#!