#!/usr/bin/env python3
"""
Force Navigation Refresh - Add Cache Busting
"""

import os
import time

def add_cache_busting_to_back_buttons():
    """Add cache busting parameters to back buttons"""
    
    print("🔧 Adding Cache Busting to Back Buttons...")
    print("=" * 60)
    
    # Find all objective template files
    template_dir = "sustainable_energy/dashboard/templates/dashboard/"
    
    for i in range(1, 9):
        file_path = f"{template_dir}objective{i}.html"
        
        if os.path.exists(file_path):
            print(f"🔧 Processing: {file_path}")
            
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Add timestamp to force cache refresh
            timestamp = str(int(time.time()))
            
            # Replace the back button navigation
            old_nav = "window.location.href='/'"
            new_nav = f"window.location.href='/?t={timestamp}'"
            
            if old_nav in content:
                content = content.replace(old_nav, new_nav)
                
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                
                print(f"   ✅ Added cache busting parameter: ?t={timestamp}")
            else:
                print(f"   ⚠️  No back button found to update")

def create_simple_test_file():
    """Create a simple test file without unicode issues"""
    
    test_html = '''<!DOCTYPE html>
<html>
<head>
    <title>Navigation Test</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        button { padding: 15px 30px; font-size: 18px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background: #0056b3; }
        .test-section { margin: 20px 0; padding: 20px; border: 1px solid #ddd; border-radius: 5px; }
    </style>
</head>
<body>
    <h1>Back to Objectives Navigation Test</h1>
    
    <div class="test-section">
        <h2>Test the Back Button Navigation:</h2>
        <button onclick="window.location.href='/'">
            Back to Objectives (Test)
        </button>
        <p><strong>Expected:</strong> Should take you to page with 8 objective cards</p>
    </div>
    
    <div class="test-section">
        <h2>Direct Navigation Links:</h2>
        <ul>
            <li><a href="/">Root Page (/)</a> - Should show objectives page</li>
            <li><a href="/objective1/">Objective 1</a> - Individual objective page</li>
            <li><a href="/explore/">Explore Dashboard</a> - Explore page</li>
        </ul>
    </div>
    
    <div class="test-section">
        <h2>Troubleshooting Steps:</h2>
        <ol>
            <li>Click the blue "Back to Objectives" button above</li>
            <li>You should see a page with 8 objective cards</li>
            <li>If not, try: Ctrl+F5 (hard refresh)</li>
            <li>Or try: Clear browser cache and cookies</li>
            <li>Or try: Open in incognito/private mode</li>
        </ol>
    </div>
</body>
</html>'''
    
    with open('navigation_test.html', 'w', encoding='utf-8') as f:
        f.write(test_html)
    
    print("✅ Created navigation_test.html")
    print("🌐 Open this file in your browser to test navigation")

def show_cache_clearing_instructions():
    """Show cache clearing instructions"""
    
    print(f"\n" + "=" * 60)
    print("🧹 CACHE CLEARING INSTRUCTIONS:")
    print("=" * 60)
    print("The navigation IS working correctly on the server side.")
    print("If you're not seeing the objectives page, it's likely a browser cache issue.")
    print("")
    print("Try these steps in order:")
    print("")
    print("1. 🔄 Hard Refresh:")
    print("   - Windows/Linux: Ctrl + F5 or Ctrl + Shift + R")
    print("   - Mac: Cmd + Shift + R")
    print("")
    print("2. 🧹 Clear Browser Cache:")
    print("   - Chrome: Settings > Privacy > Clear browsing data")
    print("   - Firefox: Settings > Privacy > Clear Data")
    print("   - Edge: Settings > Privacy > Clear browsing data")
    print("")
    print("3. 🕵️ Try Incognito/Private Mode:")
    print("   - This bypasses all cache and cookies")
    print("")
    print("4. 🔄 Restart Django Server:")
    print("   - Stop server: Ctrl + C")
    print("   - Start server: python manage.py runserver")

if __name__ == "__main__":
    add_cache_busting_to_back_buttons()
    create_simple_test_file()
    show_cache_clearing_instructions()
    
    print(f"\n" + "=" * 60)
    print("✅ SUMMARY:")
    print("✅ Server-side navigation is working correctly")
    print("✅ Root page serves objectives page with all 8 cards")
    print("✅ Added cache busting to force refresh")
    print("🔄 Please try hard refresh (Ctrl+F5) or clear browser cache")